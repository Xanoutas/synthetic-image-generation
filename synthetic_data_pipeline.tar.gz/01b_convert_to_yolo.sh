#!/bin/bash
# =============================================================================
# CONVERT JSON ANNOTATIONS → YOLO FORMAT
# =============================================================================
set -e

INPUT_DIR="$HOME/synthetic_data/industrial_defects/renders"
YOLO_DIR="$HOME/synthetic_data/industrial_defects/yolo"

echo "[YOLO] Converting annotations to YOLO format..."

mkdir -p "$YOLO_DIR/images/train" "$YOLO_DIR/labels/train"
mkdir -p "$YOLO_DIR/images/val" "$YOLO_DIR/labels/val"

python3 << 'PYEOF'
import json, os, shutil, random
from pathlib import Path

input_dir = os.environ.get('INPUT_DIR', '')
yolo_dir = os.environ.get('YOLO_DIR', '')

classes = ['scratch', 'dent', 'crack', 'corrosion', 'discoloration']
class_map = {c: i for i, c in enumerate(classes)}

images = sorted(Path(f"{input_dir}/images").glob("*.png"))
random.shuffle(images)
split = int(len(images) * 0.9)
train_imgs = images[:split]
val_imgs = images[split:]

def process_split(img_list, split_name):
    for img_path in img_list:
        ann_path = Path(f"{input_dir}/annotations") / img_path.name.replace('.png', '.json')
        if not ann_path.exists():
            continue
        with open(ann_path) as f:
            ann = json.load(f)

        # Copy image
        dst_img = Path(f"{yolo_dir}/images/{split_name}") / img_path.name
        shutil.copy(img_path, dst_img)

        # Write YOLO label
        label_path = Path(f"{yolo_dir}/labels/{split_name}") / img_path.name.replace('.png', '.txt')
        with open(label_path, 'w') as f:
            for obj in ann.get('objects', []):
                cls = obj['class']
                bbox = obj['bbox_yolo']
                f.write(f"{class_map[cls]} {bbox[0]:.6f} {bbox[1]:.6f} {bbox[2]:.6f} {bbox[3]:.6f}\n")

process_split(train_imgs, 'train')
process_split(val_imgs, 'val')

# Write data.yaml
yaml_path = Path(f"{yolo_dir}/data.yaml")
with open(yaml_path, 'w') as f:
    f.write(f"path: {yolo_dir}\n")
    f.write("train: images/train\n")
    f.write("val: images/val\n")
    f.write(f"nc: {len(classes)}\n")
    f.write(f"names: {classes}\n")

print(f"YOLO dataset ready at: {yolo_dir}")
print(f"  Train: {len(train_imgs)} images")
print(f"  Val:   {len(val_imgs)} images")
PYEOF

echo "[YOLO] Conversion complete!"
echo "  Dataset: $YOLO_DIR"
echo "  YAML:    $YOLO_DIR/data.yaml"
