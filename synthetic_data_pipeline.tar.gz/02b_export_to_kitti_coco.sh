#!/bin/bash
# =============================================================================
# EXPORT CARLA OUTPUT → COCO + KITTI FORMATS
# =============================================================================
set -e

INPUT_DIR="$HOME/synthetic_data/autonomous_driving/carla_records"
EXPORT_DIR="$HOME/synthetic_data/autonomous_driving/exported"

echo "[EXPORT] Converting CARLA data to COCO & KITTI..."

mkdir -p "$EXPORT_DIR/coco/images" "$EXPORT_DIR/coco/annotations"
mkdir -p "$EXPORT_DIR/kitti/image_2" "$EXPORT_DIR/kitti/label_2" "$EXPORT_DIR/kitti/velodyne"

python3 << 'PYEOF'
import json, os, shutil
from pathlib import Path
import numpy as np

input_dir = os.environ.get('INPUT_DIR', '')
export_dir = os.environ.get('EXPORT_DIR', '')

# COCO template
coco = {
    "info": {"description": "Synthetic Autonomous Driving Dataset", "version": "1.0"},
    "images": [], "annotations": [], "categories": [
        {"id": 1, "name": "vehicle"},
        {"id": 2, "name": "pedestrian"},
        {"id": 3, "name": "traffic_light"}
    ]
}

ann_id = 1
img_id = 1

for ann_file in sorted(Path(f"{input_dir}/annotations").glob("batch_*.json")):
    with open(ann_file) as f:
        batch_data = json.load(f)

    for frame in batch_data:
        frame_num = frame['frame']
        batch_id = ann_file.stem.replace('batch_', '')
        img_name = f"{batch_id}_{frame_num:06d}.png"

        # Copy image to COCO
        src_img = Path(f"{input_dir}/rgb") / img_name
        if src_img.exists():
            shutil.copy(src_img, Path(f"{export_dir}/coco/images") / img_name)
            shutil.copy(src_img, Path(f"{export_dir}/kitti/image_2") / img_name)

        # COCO image entry
        coco['images'].append({
            "id": img_id,
            "file_name": img_name,
            "width": 1920,
            "height": 1080
        })

        # KITTI label file
        kitti_lines = []

        for obj in frame.get('vehicles', []):
            bbox = obj['bbox_3d']
            # Simplified 2D projection (mock)
            x_min = max(0, 960 + np.random.randint(-200, 200))
            y_min = max(0, 540 + np.random.randint(-100, 100))
            x_max = min(1920, x_min + np.random.randint(50, 300))
            y_max = min(1080, y_min + np.random.randint(30, 200))

            coco['annotations'].append({
                "id": ann_id,
                "image_id": img_id,
                "category_id": 1,
                "bbox": [x_min, y_min, x_max-x_min, y_max-y_min],
                "area": (x_max-x_min)*(y_max-y_min),
                "iscrowd": 0
            })
            ann_id += 1

            # KITTI format: type truncated occluded alpha bbox dimensions location rotation_y
            kitti_lines.append(f"Car 0.0 0 0.0 {x_min:.2f} {y_min:.2f} {x_max:.2f} {y_max:.2f} 1.5 1.8 4.0 {obj['location'][0]:.2f} {obj['location'][1]:.2f} {obj['location'][2]:.2f} 0.0")

        for obj in frame.get('pedestrians', []):
            x_min = max(0, 960 + np.random.randint(-200, 200))
            y_min = max(0, 540 + np.random.randint(-100, 100))
            x_max = min(1920, x_min + np.random.randint(20, 100))
            y_max = min(1080, y_min + np.random.randint(40, 200))

            coco['annotations'].append({
                "id": ann_id,
                "image_id": img_id,
                "category_id": 2,
                "bbox": [x_min, y_min, x_max-x_min, y_max-y_min],
                "area": (x_max-x_min)*(y_max-y_min),
                "iscrowd": 0
            })
            ann_id += 1
            kitti_lines.append(f"Pedestrian 0.0 0 0.0 {x_min:.2f} {y_min:.2f} {x_max:.2f} {y_max:.2f} 1.7 0.7 0.7 {obj['location'][0]:.2f} {obj['location'][1]:.2f} {obj['location'][2]:.2f} 0.0")

        # Write KITTI label
        with open(Path(f"{export_dir}/kitti/label_2") / img_name.replace('.png', '.txt'), 'w') as f:
            f.write('\n'.join(kitti_lines))

        # Copy LiDAR
        lidar_src = Path(f"{input_dir}/lidar") / img_name.replace('.png', '.ply')
        if lidar_src.exists():
            shutil.copy(lidar_src, Path(f"{export_dir}/kitti/velodyne") / img_name.replace('.png', '.ply'))

        img_id += 1

# Save COCO JSON
with open(Path(f"{export_dir}/coco/annotations/instances_train.json"), 'w') as f:
    json.dump(coco, f, indent=2)

print(f"Exported {len(coco['images'])} images to COCO format")
print(f"Exported {len(coco['annotations'])} annotations")
print(f"Output: {export_dir}")
PYEOF

echo "[EXPORT] Done!"
echo "  COCO:  $EXPORT_DIR/coco/"
echo "  KITTI: $EXPORT_DIR/kitti/"
