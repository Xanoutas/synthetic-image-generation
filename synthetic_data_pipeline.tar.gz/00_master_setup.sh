#!/bin/bash
set -e
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}[MASTER] Starting Synthetic Data pipeline setup...${NC}"

echo -e "${YELLOW}[1/7] System deps...${NC}"
sudo apt update && sudo apt install -y \
    git curl wget unzip build-essential \
    libgl1-mesa-glx libxi6 libxrender1 libxkbcommon-x11-0 \
    libsm6 libxext6 libglfw3 libglew-dev \
    python3-pip python3-venv python3-dev \
    cmake ninja-build

echo -e "${YELLOW}[2/7] Python venv...${NC}"
python3 -m venv ~/synthetic_data_env
source ~/synthetic_data_env/bin/activate
pip install --upgrade pip wheel
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu126
pip install transformers datasets huggingface-hub accelerate diffusers
pip install opencv-python-headless pillow numpy pandas matplotlib tqdm
pip install ultralytics

echo 'source ~/synthetic_data_env/bin/activate' >> ~/.bashrc

echo -e "${YELLOW}[3/7] Blender 4.2 LTS...${NC}"
BLENDER_URL="https://download.blender.org/release/Blender4.2/blender-4.2.5-linux-x64.tar.xz"
if [ ! -d ~/blender-4.2.5-linux-x64 ]; then
    wget -q --show-progress "$BLENDER_URL" -O /tmp/blender.tar.xz
    tar -xf /tmp/blender.tar.xz -C ~/
    rm /tmp/blender.tar.xz
fi
mkdir -p ~/bin
ln -sf ~/blender-4.2.5-linux-x64/blender ~/bin/blender 2>/dev/null || true
export PATH="$HOME/bin:$PATH"
echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc

echo -e "${YELLOW}[4/7] CARLA 0.9.15...${NC}"
CARLA_URL="https://carla-releases.s3.eu-west-3.amazonaws.com/Linux/CARLA_0.9.15.tar.gz"
if [ ! -d ~/carla ]; then
    wget -q --show-progress "$CARLA_URL" -O /tmp/carla.tar.gz
    mkdir -p ~/carla
    tar -xzf /tmp/carla.tar.gz -C ~/carla
    rm /tmp/carla.tar.gz
fi
export CARLA_ROOT="$HOME/carla"
echo 'export CARLA_ROOT="$HOME/carla"' >> ~/.bashrc

echo -e "${YELLOW}[5/7] HF CLI...${NC}"
pip install -U huggingface-hub

echo -e "${YELLOW}[6/7] Workspace dirs...${NC}"
mkdir -p ~/synthetic_data/{industrial_defects,autonomous_driving,hf_upload,scripts,marketing}
mkdir -p ~/synthetic_data/industrial_defects/{renders,annotations,teaser,full}
mkdir -p ~/synthetic_data/autonomous_driving/{carla_records,exported,teaser,full}

echo -e "${GREEN}[MASTER] DONE!${NC}"
echo "Next: 1) huggingface-cli login"
echo "      2) cd ~/synthetic_data/scripts"
echo "      3) bash 01_generate_industrial_defects.sh"
