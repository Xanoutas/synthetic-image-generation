#!/bin/bash
# =============================================================================
# UPLOAD DATASETS TO HUGGING FACE (Teaser + Full)
# =============================================================================
set -e

HF_USER="your_username"  # <-- CHANGE THIS
TEASER_SIZE=1000

echo "[HF] Preparing datasets for Hugging Face upload..."
echo "⚠️  Make sure you ran: huggingface-cli login"

# --- Industrial Defects ---
IND_DIR="$HOME/synthetic_data/industrial_defects"
IND_TEASER="$IND_DIR/teaser"
IND_FULL="$IND_DIR/full"

mkdir -p "$IND_TEASER/images" "$IND_TEASER/labels"
mkdir -p "$IND_FULL/images" "$IND_FULL/labels"

python3 << 'PYEOF'
import os, shutil, random
from pathlib import Path

ind_dir = os.environ.get('IND_DIR', '')
teaser_size = int(os.environ.get('TEASER_SIZE', '100'))

# Get all images
all_imgs = sorted(Path(f"{ind_dir}/yolo/images/train").glob("*.png"))
random.shuffle(all_imgs)

teaser_imgs = all_imgs[:teaser_size]
full_imgs = all_imgs

for img in teaser_imgs:
    label = img.name.replace('.png', '.txt')
    label_src = Path(f"{ind_dir}/yolo/labels/train") / label
    shutil.copy(img, Path(f"{ind_dir}/teaser/images") / img.name)
    if label_src.exists():
        shutil.copy(label_src, Path(f"{ind_dir}/teaser/labels") / label)

for img in full_imgs:
    label = img.name.replace('.png', '.txt')
    label_src = Path(f"{ind_dir}/yolo/labels/train") / label
    shutil.copy(img, Path(f"{ind_dir}/full/images") / img.name)
    if label_src.exists():
        shutil.copy(label_src, Path(f"{ind_dir}/full/labels") / label)

print(f"Teaser: {len(teaser_imgs)} images")
print(f"Full:   {len(full_imgs)} images")
PYEOF

# --- Create HF dataset repos ---
echo "[HF] Creating dataset repositories..."

# Teaser repo (public)
if ! huggingface-cli repo info "${HF_USER}/synthetic-industrial-defects-teaser" 2>/dev/null; then
    huggingface-cli repo create "synthetic-industrial-defects-teaser" --type dataset --yes
fi

# Full repo (private, will be gated)
if ! huggingface-cli repo info "${HF_USER}/synthetic-industrial-defects-full" 2>/dev/null; then
    huggingface-cli repo create "synthetic-industrial-defects-full" --type dataset --yes --private
fi

# --- Upload Teaser ---
echo "[HF] Uploading TEASER dataset..."
cd "$IND_TEASER"
git init 2>/dev/null || true
git remote add origin "https://huggingface.co/datasets/${HF_USER}/synthetic-industrial-defects-teaser" 2>/dev/null || true

# Create dataset card
cat > README.md << 'EOF'
---
license: mit
tags:
- synthetic-data
- computer-vision
- industrial-inspection
- defect-detection
datasets:
- synthetic
size_categories:
- 1K<n<10K
---

# Synthetic Industrial Defects — Teaser

## Dataset Description
1000 synthetic images of industrial metal surfaces with 5 defect types:
- **Scratch**: Surface scratches of varying depth and length
- **Dent**: Localized deformations on metal surface
- **Crack**: Linear fractures
- **Corrosion**: Oxidation patterns using procedural noise
- **Discoloration**: Color variations indicating contamination

## Format
- Images: PNG (1920x1080)
- Annotations: YOLO format (.txt files)
- Classes: 5

## Generation
Generated using Blender 4.2 with procedural geometry and materials.
Camera and lighting randomized for domain diversity.

## Usage
```python
from datasets import load_dataset
ds = load_dataset("HF_USER/synthetic-industrial-defects-teaser")
```

## Full Dataset
The complete dataset (50K+ images) with additional defect types and multi-lighting conditions is available for purchase.
Contact: your-email@example.com

## Citation
```bibtex
@dataset{synthetic_industrial_defects_2026,
  author = {YOUR_NAME},
  title = {Synthetic Industrial Defects Dataset},
  year = {2026},
  url = {https://huggingface.co/datasets/HF_USER/synthetic-industrial-defects-teaser}
}
```
EOF

# Fix HF_USER placeholder
sed -i "s/HF_USER/${HF_USER}/g" README.md

git add .
git commit -m "Initial teaser upload" 2>/dev/null || true
git push -u origin main --force

# --- Upload Full (private, gated setup) ---
echo "[HF] Uploading FULL dataset (private)..."
cd "$IND_FULL"
git init 2>/dev/null || true
git remote add origin "https://huggingface.co/datasets/${HF_USER}/synthetic-industrial-defects-full" 2>/dev/null || true

cat > README.md << 'EOF'
---
license: other
tags:
- synthetic-data
- computer-vision
- industrial-inspection
gated: true
---

# Synthetic Industrial Defects — Full Dataset

## 🔒 Access
This dataset is **gated**. To gain access:

1. Fill the access request form above
2. Purchase unlock key: [Gumroad Link] or contact us
3. After payment confirmation, access will be granted within 24h

## What's Inside
- **50,000+ images** (1920x1080 PNG)
- **5 defect types**: scratch, dent, crack, corrosion, discoloration
- **YOLO annotations** ready for training
- **Multi-lighting conditions**: 3-point, area, directional
- **Camera angles**: 15°–75° tilt variations

## Pricing
- **Basic** (10K images, 3 defect types): $49
- **Pro** (50K images, 5 defect types, multi-lighting): $149
- **Enterprise** (Custom generation, specific materials): Contact us

## Contact
- Email: your-email@example.com
- LinkedIn: [Your Profile]

## License
Commercial use allowed with purchased license.
EOF

git add .
git commit -m "Initial full dataset upload" 2>/dev/null || true
git push -u origin main --force

echo "[HF] Upload complete!"
echo "  Teaser: https://huggingface.co/datasets/${HF_USER}/synthetic-industrial-defects-teaser"
echo "  Full:   https://huggingface.co/datasets/${HF_USER}/synthetic-industrial-defects-full"
echo ""
echo "Next steps:"
echo "  1. Go to https://huggingface.co/datasets/${HF_USER}/synthetic-industrial-defects-full/settings"
echo "  2. Enable 'Gated Dataset'"
echo "  3. Add your Gumroad/Stripe payment link to README"
echo "  4. Set up Gumroad product page"
