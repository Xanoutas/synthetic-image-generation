# 🏭 Synthetic Data Generation Pipeline

Πλήρες CLI toolkit για παραγωγή synthetic datasets (Industrial Defects + Autonomous Driving) και πώληση στο Hugging Face.

## ⚡ Quick Start

```bash
# 1. Download & extract
wget [LINK] -O synthetic_data_cli.tar.gz
tar -xzf synthetic_data_cli.tar.gz
cd synthetic_data_cli

# 2. Run master setup (εγκαθιστά Blender, CARLA, Python libs)
bash 00_master_setup.sh

# 3. Login to Hugging Face
huggingface-cli login

# 4. Generate Industrial Defects
bash 01_generate_industrial_defects.sh

# 5. Convert to YOLO
bash 01b_convert_to_yolo.sh

# 6. Validate quality (train YOLOv8)
bash 05_validate_yolo.sh

# 7. Upload to Hugging Face
bash 03_upload_to_hf.sh

# 8. Setup monetization
bash 04_setup_monetization.sh
```

## 📁 File Structure

```
synthetic_data_cli/
├── 00_master_setup.sh              # Εγκατάσταση όλων των dependencies
├── 01_generate_industrial_defects.sh  # Blender batch renderer
├── generate_defects.py             # Blender Python script (procedural defects)
├── 01b_convert_to_yolo.sh          # JSON → YOLO format conversion
├── 02_generate_autonomous_driving.sh  # CARLA batch generator
├── generate_carla.py               # CARLA Python API script
├── 02b_export_to_kitti_coco.sh     # CARLA → COCO/KITTI export
├── 03_upload_to_hf.sh              # Hugging Face upload + gated access
├── 04_setup_monetization.sh        # Gumroad/Stripe templates
├── 05_validate_yolo.sh             # YOLOv8 training validation
└── README.md                       # This file
```

## 🔧 Hardware Requirements

- **OS**: Ubuntu 22.04/24.04 LTS
- **GPU**: 2× NVIDIA RTX 5070 (12GB VRAM each)
- **RAM**: 32GB+ recommended
- **Storage**: 100GB+ free space
- **CUDA**: 12.6+

## 📊 Datasets

### Industrial Defects
| Property | Value |
|----------|-------|
| Images | 1,000–50,000+ |
| Resolution | 1920×1080 PNG |
| Defect Types | 5 (scratch, dent, crack, corrosion, discoloration) |
| Annotations | YOLO bbox + COCO JSON |
| Lighting | Randomized 3-point/area setup |
| Camera | Random tilt 15°–75° |

### Autonomous Driving
| Property | Value |
|----------|-------|
| Frames | 1,000–10,000+ |
| Resolution | 1920×1080 |
| Modalities | RGB, Depth, Semantic Segmentation, LiDAR |
| Annotations | 3D bbox, 2D bbox (COCO/KITTI) |
| Weather | Clear, Rain, Fog, Sunset |
| Traffic | 30+ vehicles, 20+ pedestrians |

## 💰 Monetization Strategy

| Tier | Content | Price |
|------|---------|-------|
| **Free Teaser** | 1,000 images, public HF repo | $0 |
| **Basic** | 10,000 images, 3 defect types | $49 |
| **Pro** | 50,000 images, 5 types, multi-lighting | $149 |
| **Enterprise** | Custom generation, specific materials | $499+ |
| **AD Batch** | 1,000 frames (RGB+LiDAR+annotations) | $299 |

## 🚀 Marketing Checklist

- [ ] Post on LinkedIn: "Synthetic Industrial Defect Dataset — 50K images, YOLO-ready"
- [ ] Share on Reddit: r/MachineLearning, r/computervision
- [ ] Contact 10 CV startups via LinkedIn
- [ ] Join Discord: Computer Vision, ML Ops
- [ ] Write Medium article: "How I generated $1K/mo selling synthetic data"
- [ ] Twitter/X thread with sample images

## 🐛 Troubleshooting

### Blender not found
```bash
export PATH="$HOME/bin:$PATH"
```

### CARLA connection refused
```bash
# Terminal 1: Start CARLA server
~/carla/CarlaUE4.sh -RenderOffScreen

# Terminal 2: Run generator
bash 02_generate_autonomous_driving.sh
```

### CUDA out of memory
Reduce `SCENE_COUNT` or set `GPU_RENDER=false` in scripts.

### HF upload fails
```bash
huggingface-cli login  # Re-authenticate
git config --global credential.helper store
```

## 📧 Support

For issues or custom requests: your-email@example.com

## 📜 License

Scripts: MIT
Generated datasets: Commercial license with purchase
