#!/bin/bash
# =============================================================================
# VALIDATE — Train YOLOv8 on synthetic data to verify quality
# =============================================================================
set -e

YOLO_DIR="$HOME/synthetic_data/industrial_defects/yolo"
RESULTS_DIR="$HOME/synthetic_data/industrial_defects/validation"

echo "[VALIDATE] Training YOLOv8n on synthetic data..."
mkdir -p "$RESULTS_DIR"

source ~/synthetic_data_env/bin/activate

python3 << 'PYEOF'
from ultralytics import YOLO
import os

yolo_dir = os.environ.get('YOLO_DIR', '')
results_dir = os.environ.get('RESULTS_DIR', '')

# Train
model = YOLO('yolov8n.pt')
results = model.train(
    data=f"{yolo_dir}/data.yaml",
    epochs=50,
    imgsz=640,
    batch=16,
    project=results_dir,
    name='synthetic_defects',
    exist_ok=True
)

# Validate
metrics = model.val()
print(f"\n{'='*50}")
print(f"VALIDATION RESULTS")
print(f"{'='*50}")
print(f"mAP@50:      {metrics.box.map50:.4f}")
print(f"mAP@50-95:   {metrics.box.map:.4f}")
print(f"Precision:   {metrics.box.mp:.4f}")
print(f"Recall:      {metrics.box.mr:.4f}")
print(f"{'='*50}")

# Save results summary
with open(f"{results_dir}/validation_summary.txt", 'w') as f:
    f.write(f"mAP@50:    {metrics.box.map50:.4f}\n")
    f.write(f"mAP@50-95: {metrics.box.map:.4f}\n")
    f.write(f"Precision: {metrics.box.mp:.4f}\n")
    f.write(f"Recall:    {metrics.box.mr:.4f}\n")

print(f"\nResults saved to: {results_dir}/validation_summary.txt")
PYEOF

echo "[VALIDATE] Done! Check results above."
