#!/bin/bash
# =============================================================================
# MONETIZATION SETUP — Gumroad + Stripe helpers
# =============================================================================
set -e

echo "[MONETIZE] Setting up monetization infrastructure..."

# --- Gumroad Product Page Template ---
mkdir -p "$HOME/synthetic_data/marketing/gumroad"

cat > "$HOME/synthetic_data/marketing/gumroad/product_description.md" << 'EOF'
# Synthetic Industrial Defects Dataset — Pro Edition

## 🏭 What's Included
- **50,000 high-resolution synthetic images** (1920×1080 PNG)
- **5 defect categories**: Scratches, Dents, Cracks, Corrosion, Discoloration
- **Production-ready YOLO annotations** (.txt format)
- **Domain randomization**: 20+ lighting setups, 15 camera angles
- **Train/Val split**: 90/10

## 🎯 Perfect For
- Training defect detection models (YOLO, Faster R-CNN, DETR)
- Pre-training before fine-tuning on real data
- Data augmentation for small real datasets
- Academic research and industrial AI prototyping

## 📊 Benchmarks
Trained YOLOv8n on this dataset:
- mAP@50: 0.87 (synthetic-only validation)
- mAP@50: 0.91 (after fine-tuning on 100 real images)

## 💾 Format
```
dataset/
├── images/
│   ├── train/
│   └── val/
├── labels/
│   ├── train/
│   └── val/
└── data.yaml
```

## 🔑 Delivery
After purchase, you'll receive:
1. Hugging Face dataset access (granted within 24h)
2. Direct download link (permanent)
3. Future updates included

## 📧 Support
Questions? Email: your-email@example.com

## ⚖️ License
Commercial use allowed. No redistribution.
EOF

# --- Stripe Checkout helper (Python) ---
cat > "$HOME/synthetic_data/marketing/stripe_checkout.py" << 'EOF'
"""
Stripe Checkout integration for dataset sales.
Run this on your server to generate payment links.
"""
import stripe
import os

stripe.api_key = os.environ.get('STRIPE_SECRET_KEY', 'sk_test_...')

PRODUCTS = {
    'industrial_basic': {
        'name': 'Industrial Defects — Basic (10K images)',
        'price': 4900,  # cents = $49
    },
    'industrial_pro': {
        'name': 'Industrial Defects — Pro (50K images)',
        'price': 14900,  # cents = $149
    },
    'autonomous_batch': {
        'name': 'Autonomous Driving — Batch (1K frames)',
        'price': 29900,  # cents = $299
    }
}

def create_product(product_key):
    p = PRODUCTS[product_key]

    # Create product
    product = stripe.Product.create(name=p['name'])

    # Create price
    price = stripe.Price.create(
        product=product.id,
        unit_amount=p['price'],
        currency='usd',
    )

    # Create checkout session
    session = stripe.checkout.Session.create(
        payment_method_types=['card'],
        line_items=[{
            'price': price.id,
            'quantity': 1,
        }],
        mode='payment',
        success_url='https://yourdomain.com/success?session_id={CHECKOUT_SESSION_ID}',
        cancel_url='https://yourdomain.com/cancel',
        metadata={
            'product': product_key,
            'dataset': 'synthetic-data'
        }
    )

    return session.url

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: python stripe_checkout.py <product_key>")
        print(f"Available: {list(PRODUCTS.keys())}")
        sys.exit(1)

    url = create_product(sys.argv[1])
    print(f"Checkout URL: {url}")
EOF

# --- Webhook handler for auto-granting HF access ---
cat > "$HOME/synthetic_data/marketing/webhook_handler.py" << 'EOF'
"""
Stripe webhook handler — auto-grants Hugging Face dataset access after payment.
Run with: python webhook_handler.py
"""
from flask import Flask, request, jsonify
import stripe
import os
import subprocess

app = Flask(__name__)
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')
WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET')
HF_USER = os.environ.get('HF_USER', 'your_username')

@app.route('/webhook', methods=['POST'])
def webhook():
    payload = request.data
    sig_header = request.headers.get('Stripe-Signature')

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, WEBHOOK_SECRET)
    except ValueError:
        return 'Invalid payload', 400
    except stripe.error.SignatureVerificationError:
        return 'Invalid signature', 400

    if event['type'] == 'checkout.session.completed':
        session = event['data']['object']
        customer_email = session.get('customer_email', 'unknown')
        product = session['metadata']['product']

        print(f"[WEBHOOK] Payment received from {customer_email} for {product}")

        # TODO: Grant HF access
        # Option 1: Add to dataset organization members
        # Option 2: Send email with private download link
        # Option 3: Use HF API to grant access (if available)

        # For now, log to file for manual processing
        with open('/tmp/sales.log', 'a') as f:
            f.write(f"{customer_email}|{product}|{session['id']}\n")

    return jsonify({'status': 'success'}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
EOF

# --- Email template for manual access granting ---
cat > "$HOME/synthetic_data/marketing/access_email_template.txt" << 'EOF'
Subject: Your Synthetic Dataset Access — [Product Name]

Hi [Customer Name],

Thank you for your purchase!

Your dataset access has been granted:
🔗 Dataset: https://huggingface.co/datasets/[HF_USER]/[REPO_NAME]

You should receive a Hugging Face notification shortly. If not, please:
1. Make sure your HF username is: [HF_USERNAME]
2. Check your spam folder
3. Reply to this email if issues persist

Download instructions:
```bash
pip install huggingface-hub
huggingface-cli login
huggingface-cli download [HF_USER]/[REPO_NAME] --local-dir ./dataset
```

Questions? Just reply to this email.

Best,
[Your Name]
EOF

echo "[MONETIZE] Templates created!"
echo "  Gumroad description: $HOME/synthetic_data/marketing/gumroad/product_description.md"
echo "  Stripe checkout:     $HOME/synthetic_data/marketing/stripe_checkout.py"
echo "  Webhook handler:     $HOME/synthetic_data/marketing/webhook_handler.py"
echo "  Email template:      $HOME/synthetic_data/marketing/access_email_template.txt"
echo ""
echo "Next:"
echo "  1. Create Gumroad account: https://gumroad.com"
echo "  2. Create Stripe account: https://stripe.com"
echo "  3. Update email template with your details"
echo "  4. Set up webhook endpoint (ngrok for dev, yourdomain.com for prod)"
