#!/bin/bash
set -e
OUTPUT_BASE="$HOME/synthetic_data/industrial_defects"
SCENE_COUNT=1000
RES_X=1920
RES_Y=1080
GPU_RENDER=true

echo "[INDUSTRIAL] Generating $SCENE_COUNT defect images..."

export OUTPUT_DIR="$OUTPUT_BASE/renders"
export SCENE_COUNT=$SCENE_COUNT
export RES_X=$RES_X
export RES_Y=$RES_Y
export GPU_RENDER=$GPU_RENDER

~/blender-4.2.5-linux-x64/blender --background --python "$HOME/synthetic_data/scripts/generate_defects.py"

echo "[INDUSTRIAL] Done!"
echo "  Images:     $OUTPUT_BASE/renders/images/"
echo "  Annotations: $OUTPUT_BASE/renders/annotations/"
echo "Next: bash 01b_convert_to_yolo.sh"
