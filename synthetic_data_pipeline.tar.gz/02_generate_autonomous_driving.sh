#!/bin/bash
# =============================================================================
# AUTONOMOUS DRIVING — CARLA Batch Generator
# Πρέπει πρώτα να τρέξεις: ~/carla/CarlaUE4.sh -RenderOffScreen
# =============================================================================
set -e

OUTPUT_BASE="$HOME/synthetic_data/autonomous_driving"
NUM_BATCHES=5
FRAMES_PER_BATCH=200
RES_X=1920
RES_Y=1080

echo "[CARLA] Starting $NUM_BATCHES batches x $FRAMES_PER_BATCH frames..."
echo "⚠️  Make sure CARLA server is running: ~/carla/CarlaUE4.sh -RenderOffScreen"

export OUTPUT_DIR="$OUTPUT_BASE/carla_records"
export NUM_FRAMES=$FRAMES_PER_BATCH
export RES_X=$RES_X
export RES_Y=$RES_Y

for i in $(seq 0 $((NUM_BATCHES-1))); do
    echo "[CARLA] === BATCH $i ==="
    export BATCH_ID=$i
    python3 "$HOME/synthetic_data/scripts/generate_carla.py"
    sleep 2
done

echo "[CARLA] All batches complete!"
echo "  Output: $OUTPUT_BASE/carla_records/"
echo "Next: bash 02b_export_to_kitti_coco.sh"
