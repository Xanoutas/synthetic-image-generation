import carla
import random
import os
import json
import time

OUTPUT_DIR = os.environ.get('OUTPUT_DIR', '/tmp/carla_output')
BATCH_ID = os.environ.get('BATCH_ID', '0')
NUM_FRAMES = int(os.environ.get('NUM_FRAMES', '100'))
RES_X = int(os.environ.get('RES_X', '1920'))
RES_Y = int(os.environ.get('RES_Y', '1080'))

os.makedirs(f"{OUTPUT_DIR}/rgb", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/segmentation", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/depth", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/lidar", exist_ok=True)
os.makedirs(f"{OUTPUT_DIR}/annotations", exist_ok=True)

client = carla.Client('localhost', 2000)
client.set_timeout(10.0)
world = client.get_world()

weathers = [
    carla.WeatherParameters.ClearNoon,
    carla.WeatherParameters.HardRainNoon,
    carla.WeatherParameters.SoftRainSunset,
    carla.WeatherParameters.FoggyNoon,
    carla.WeatherParameters.WetCloudySunset,
]

def setup_sensors(vehicle, output_dir, batch_id):
    blueprint_library = world.get_blueprint_library()

    # RGB Camera
    cam_bp = blueprint_library.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', str(RES_X))
    cam_bp.set_attribute('image_size_y', str(RES_Y))
    cam_bp.set_attribute('fov', '110')
    cam_transform = carla.Transform(carla.Location(x=1.6, z=1.7))
    camera = world.spawn_actor(cam_bp, cam_transform, attach_to=vehicle)

    # Semantic Segmentation
    seg_bp = blueprint_library.find('sensor.camera.semantic_segmentation')
    seg_bp.set_attribute('image_size_x', str(RES_X))
    seg_bp.set_attribute('image_size_y', str(RES_Y))
    seg = world.spawn_actor(seg_bp, cam_transform, attach_to=vehicle)

    # Depth
    depth_bp = blueprint_library.find('sensor.camera.depth')
    depth_bp.set_attribute('image_size_x', str(RES_X))
    depth_bp.set_attribute('image_size_y', str(RES_Y))
    depth = world.spawn_actor(depth_bp, cam_transform, attach_to=vehicle)

    # LiDAR
    lidar_bp = blueprint_library.find('sensor.lidar.ray_cast')
    lidar_bp.set_attribute('channels', '64')
    lidar_bp.set_attribute('range', '100')
    lidar_bp.set_attribute('points_per_second', '100000')
    lidar = world.spawn_actor(lidar_bp, carla.Transform(carla.Location(z=2.0)), attach_to=vehicle)

    # Listeners
    frame_count = [0]
    annotations = []

    def parse_image(image):
        frame_count[0] += 1
        image.save_to_disk(f"{output_dir}/rgb/{batch_id}_{image.frame:06d}.png")

    def parse_seg(image):
        image.save_to_disk(f"{output_dir}/segmentation/{batch_id}_{image.frame:06d}.png",
                           carla.ColorConverter.CityScapesPalette)

    def parse_depth(image):
        image.save_to_disk(f"{output_dir}/depth/{batch_id}_{image.frame:06d}.png",
                           carla.ColorConverter.Depth)

    def parse_lidar(point_cloud):
        point_cloud.save_to_disk(f"{output_dir}/lidar/{batch_id}_{point_cloud.frame:06d}.ply")

    camera.listen(parse_image)
    seg.listen(parse_seg)
    depth.listen(parse_depth)
    lidar.listen(parse_lidar)

    return camera, seg, depth, lidar, frame_count, annotations

def get_3d_bbox(actor):
    """Get 3D bounding box corners in world space"""
    transform = actor.get_transform()
    bbox = actor.bounding_box
    extent = bbox.extent
    # Simplified: return center + extent
    return {
        'center': [bbox.location.x, bbox.location.y, bbox.location.z],
        'extent': [extent.x, extent.y, extent.z],
        'rotation': [transform.rotation.pitch, transform.rotation.yaw, transform.rotation.roll]
    }

def generate_batch(batch_id, num_frames):
    print(f"[CARLA] Starting batch {batch_id} with {num_frames} frames...")

    # Set weather
    world.set_weather(random.choice(weathers))

    # Spawn ego vehicle
    blueprint = random.choice(world.get_blueprint_library().filter('vehicle.tesla.*'))
    spawn_point = random.choice(world.get_map().get_spawn_points())
    vehicle = world.spawn_actor(blueprint, spawn_point)
    vehicle.set_autopilot(True)

    # Spawn NPC traffic
    npcs = []
    for _ in range(30):
        npc_bp = random.choice(world.get_blueprint_library().filter('vehicle.*'))
        npc_sp = random.choice(world.get_map().get_spawn_points())
        npc = world.try_spawn_actor(npc_bp, npc_sp)
        if npc:
            npc.set_autopilot(True)
            npcs.append(npc)

    # Spawn pedestrians
    walkers = []
    walker_bps = world.get_blueprint_library().filter('walker.pedestrian.*')
    for _ in range(20):
        walker_bp = random.choice(walker_bps)
        spawn = world.get_random_location_from_navigation()
        if spawn:
            walker = world.try_spawn_actor(walker_bp, carla.Transform(spawn))
            if walker:
                walkers.append(walker)

    # Setup sensors
    camera, seg, depth, lidar, frame_count, annotations = setup_sensors(
        vehicle, OUTPUT_DIR, batch_id
    )

    # Record
    for frame in range(num_frames):
        world.tick()

        # Capture annotations every frame
        frame_ann = {
            'frame': frame,
            'vehicles': [],
            'pedestrians': [],
            'traffic_lights': []
        }
        for npc in npcs:
            if npc.is_alive:
                frame_ann['vehicles'].append({
                    'id': npc.id,
                    'type': npc.type_id,
                    'bbox_3d': get_3d_bbox(npc),
                    'location': [npc.get_location().x, npc.get_location().y, npc.get_location().z]
                })
        for w in walkers:
            if w.is_alive:
                frame_ann['pedestrians'].append({
                    'id': w.id,
                    'bbox_3d': get_3d_bbox(w),
                    'location': [w.get_location().x, w.get_location().y, w.get_location().z]
                })
        annotations.append(frame_ann)

        if frame % 50 == 0:
            print(f"  Progress: {frame}/{num_frames}")

    # Save annotations
    with open(f"{OUTPUT_DIR}/annotations/batch_{batch_id}.json", 'w') as f:
        json.dump(annotations, f, indent=2)

    # Cleanup
    print("[CARLA] Cleaning up actors...")
    camera.destroy()
    seg.destroy()
    depth.destroy()
    lidar.destroy()
    vehicle.destroy()
    for npc in npcs:
        if npc.is_alive:
            npc.destroy()
    for w in walkers:
        if w.is_alive:
            w.destroy()

    print(f"[CARLA] Batch {batch_id} complete! {frame_count[0]} frames captured.")

generate_batch(BATCH_ID, NUM_FRAMES)
